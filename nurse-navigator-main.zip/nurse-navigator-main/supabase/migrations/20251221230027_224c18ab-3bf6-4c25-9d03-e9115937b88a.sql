-- Add notification preference columns to profiles table
ALTER TABLE public.profiles
ADD COLUMN IF NOT EXISTS email_training_reminders boolean DEFAULT true,
ADD COLUMN IF NOT EXISTS email_deadline_alerts boolean DEFAULT true,
ADD COLUMN IF NOT EXISTS email_completion_summary boolean DEFAULT false,
ADD COLUMN IF NOT EXISTS reminder_days_before integer DEFAULT 3;