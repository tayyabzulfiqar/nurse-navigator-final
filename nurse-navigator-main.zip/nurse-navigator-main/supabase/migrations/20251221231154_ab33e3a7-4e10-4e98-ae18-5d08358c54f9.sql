-- Create achievements table for badge definitions
CREATE TABLE public.achievements (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  name text NOT NULL,
  description text,
  icon text NOT NULL DEFAULT 'award',
  requirement_type text NOT NULL, -- 'modules_completed', 'streak_days', 'category_complete', 'time_spent'
  requirement_value integer NOT NULL,
  requirement_category text, -- optional: for category-specific achievements
  created_at timestamp with time zone NOT NULL DEFAULT now()
);

-- Create user_achievements table to track earned badges
CREATE TABLE public.user_achievements (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  user_id uuid NOT NULL,
  achievement_id uuid NOT NULL REFERENCES public.achievements(id) ON DELETE CASCADE,
  earned_at timestamp with time zone NOT NULL DEFAULT now(),
  UNIQUE(user_id, achievement_id)
);

-- Create weekly_goals table
CREATE TABLE public.weekly_goals (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  user_id uuid NOT NULL,
  week_start date NOT NULL,
  target_modules integer NOT NULL DEFAULT 3,
  target_minutes integer NOT NULL DEFAULT 60,
  created_at timestamp with time zone NOT NULL DEFAULT now(),
  updated_at timestamp with time zone NOT NULL DEFAULT now(),
  UNIQUE(user_id, week_start)
);

-- Enable RLS
ALTER TABLE public.achievements ENABLE ROW LEVEL SECURITY;
ALTER TABLE public.user_achievements ENABLE ROW LEVEL SECURITY;
ALTER TABLE public.weekly_goals ENABLE ROW LEVEL SECURITY;

-- RLS Policies for achievements (public read)
CREATE POLICY "Anyone can view achievements" 
ON public.achievements 
FOR SELECT 
USING (true);

-- RLS Policies for user_achievements
CREATE POLICY "Users can view their own achievements" 
ON public.user_achievements 
FOR SELECT 
USING (auth.uid() = user_id);

CREATE POLICY "Users can insert their own achievements" 
ON public.user_achievements 
FOR INSERT 
WITH CHECK (auth.uid() = user_id);

-- RLS Policies for weekly_goals
CREATE POLICY "Users can view their own weekly goals" 
ON public.weekly_goals 
FOR SELECT 
USING (auth.uid() = user_id);

CREATE POLICY "Users can insert their own weekly goals" 
ON public.weekly_goals 
FOR INSERT 
WITH CHECK (auth.uid() = user_id);

CREATE POLICY "Users can update their own weekly goals" 
ON public.weekly_goals 
FOR UPDATE 
USING (auth.uid() = user_id);

-- Add trigger for weekly_goals updated_at
CREATE TRIGGER update_weekly_goals_updated_at
BEFORE UPDATE ON public.weekly_goals
FOR EACH ROW
EXECUTE FUNCTION public.update_updated_at_column();

-- Insert default achievements
INSERT INTO public.achievements (name, description, icon, requirement_type, requirement_value) VALUES
('First Steps', 'Complete your first training module', 'footprints', 'modules_completed', 1),
('Getting Started', 'Complete 5 training modules', 'rocket', 'modules_completed', 5),
('Dedicated Learner', 'Complete 10 training modules', 'book-open', 'modules_completed', 10),
('Training Champion', 'Complete 25 training modules', 'trophy', 'modules_completed', 25),
('Master Achiever', 'Complete 50 training modules', 'crown', 'modules_completed', 50),
('Quick Learner', 'Spend 1 hour on training', 'clock', 'time_spent', 60),
('Committed', 'Spend 5 hours on training', 'timer', 'time_spent', 300),
('Expert', 'Spend 10 hours on training', 'graduation-cap', 'time_spent', 600);