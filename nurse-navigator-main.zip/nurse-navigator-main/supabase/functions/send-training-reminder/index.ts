import { serve } from "https://deno.land/std@0.190.0/http/server.ts";
import { createClient } from "https://esm.sh/@supabase/supabase-js@2.89.0";
import { Resend } from "https://esm.sh/resend@2.0.0";

const resend = new Resend(Deno.env.get("RESEND_API_KEY"));

const corsHeaders = {
  "Access-Control-Allow-Origin": "*",
  "Access-Control-Allow-Headers": "authorization, x-client-info, apikey, content-type",
};

interface TrainingReminder {
  user_email: string;
  user_name: string;
  module_title: string;
  due_date: string;
  reminder_type: "due_soon" | "expiring_soon" | "overdue";
}

const handler = async (req: Request): Promise<Response> => {
  if (req.method === "OPTIONS") {
    return new Response(null, { headers: corsHeaders });
  }

  try {
    const supabaseUrl = Deno.env.get("SUPABASE_URL")!;
    const supabaseServiceKey = Deno.env.get("SUPABASE_SERVICE_ROLE_KEY")!;
    const supabase = createClient(supabaseUrl, supabaseServiceKey);

    // Get training modules that are due soon (within 7 days) or expiring soon
    const now = new Date();
    const sevenDaysFromNow = new Date(now.getTime() + 7 * 24 * 60 * 60 * 1000);

    // Get users with upcoming due dates
    const { data: upcomingDue, error: dueError } = await supabase
      .from("user_progress")
      .select(`
        user_id,
        due_date,
        module_id,
        training_modules (title)
      `)
      .eq("status", "in_progress")
      .gte("due_date", now.toISOString())
      .lte("due_date", sevenDaysFromNow.toISOString());

    if (dueError) {
      console.error("Error fetching due dates:", dueError);
    }

    // Get expiring certificates (within 30 days)
    const thirtyDaysFromNow = new Date(now.getTime() + 30 * 24 * 60 * 60 * 1000);
    const { data: expiringCerts, error: expiringError } = await supabase
      .from("compliance_records")
      .select(`
        user_id,
        expiry_date,
        module_id,
        training_modules (title)
      `)
      .eq("is_valid", true)
      .gte("expiry_date", now.toISOString())
      .lte("expiry_date", thirtyDaysFromNow.toISOString());

    if (expiringError) {
      console.error("Error fetching expiring certs:", expiringError);
    }

    const emailsSent: string[] = [];

    // Send reminders for upcoming due dates
    if (upcomingDue?.length) {
      for (const item of upcomingDue) {
        const { data: profile } = await supabase
          .from("profiles")
          .select("first_name, last_name")
          .eq("user_id", item.user_id)
          .single();

        const { data: authUser } = await supabase.auth.admin.getUserById(item.user_id);

        if (authUser?.user?.email) {
          const userName = profile?.first_name || "Team Member";
          const moduleTitle = (item.training_modules as any)?.title || "Training Module";
          const dueDate = new Date(item.due_date!).toLocaleDateString();

          const emailResponse = await resend.emails.send({
            from: "Training Reminder <onboarding@resend.dev>",
            to: [authUser.user.email],
            subject: `Training Due Soon: ${moduleTitle}`,
            html: `
              <div style="font-family: Arial, sans-serif; max-width: 600px; margin: 0 auto;">
                <h1 style="color: #1a1a2e;">Training Reminder</h1>
                <p>Hi ${userName},</p>
                <p>This is a friendly reminder that your training module <strong>"${moduleTitle}"</strong> is due on <strong>${dueDate}</strong>.</p>
                <p>Please complete the training before the due date to maintain compliance.</p>
                <div style="margin: 30px 0;">
                  <a href="${Deno.env.get("SITE_URL") || "https://your-app.lovable.app"}/training/${item.module_id}" 
                     style="background: linear-gradient(135deg, #667eea 0%, #764ba2 100%); color: white; padding: 12px 24px; text-decoration: none; border-radius: 8px;">
                    Complete Training
                  </a>
                </div>
                <p style="color: #666;">Best regards,<br>The Compliance Team</p>
              </div>
            `,
          });

          emailsSent.push(authUser.user.email);
          console.log("Sent due reminder to:", authUser.user.email);
        }
      }
    }

    // Send reminders for expiring certificates
    if (expiringCerts?.length) {
      for (const item of expiringCerts) {
        const { data: profile } = await supabase
          .from("profiles")
          .select("first_name, last_name")
          .eq("user_id", item.user_id)
          .single();

        const { data: authUser } = await supabase.auth.admin.getUserById(item.user_id);

        if (authUser?.user?.email) {
          const userName = profile?.first_name || "Team Member";
          const moduleTitle = (item.training_modules as any)?.title || "Training Module";
          const expiryDate = new Date(item.expiry_date!).toLocaleDateString();

          const emailResponse = await resend.emails.send({
            from: "Compliance Alert <onboarding@resend.dev>",
            to: [authUser.user.email],
            subject: `Certificate Expiring Soon: ${moduleTitle}`,
            html: `
              <div style="font-family: Arial, sans-serif; max-width: 600px; margin: 0 auto;">
                <h1 style="color: #dc2626;">Certificate Expiring Soon</h1>
                <p>Hi ${userName},</p>
                <p>Your compliance certificate for <strong>"${moduleTitle}"</strong> will expire on <strong>${expiryDate}</strong>.</p>
                <p>Please retake the training to renew your certification and maintain compliance.</p>
                <div style="margin: 30px 0;">
                  <a href="${Deno.env.get("SITE_URL") || "https://your-app.lovable.app"}/training/${item.module_id}" 
                     style="background: linear-gradient(135deg, #dc2626 0%, #991b1b 100%); color: white; padding: 12px 24px; text-decoration: none; border-radius: 8px;">
                    Renew Certification
                  </a>
                </div>
                <p style="color: #666;">Best regards,<br>The Compliance Team</p>
              </div>
            `,
          });

          emailsSent.push(authUser.user.email);
          console.log("Sent expiry reminder to:", authUser.user.email);
        }
      }
    }

    return new Response(
      JSON.stringify({ 
        success: true, 
        emailsSent: emailsSent.length,
        recipients: emailsSent 
      }),
      {
        status: 200,
        headers: { "Content-Type": "application/json", ...corsHeaders },
      }
    );
  } catch (error: any) {
    console.error("Error in send-training-reminder function:", error);
    return new Response(
      JSON.stringify({ error: error.message }),
      {
        status: 500,
        headers: { "Content-Type": "application/json", ...corsHeaders },
      }
    );
  }
};

serve(handler);
