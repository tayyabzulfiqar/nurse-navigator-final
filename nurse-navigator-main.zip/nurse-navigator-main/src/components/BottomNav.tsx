import { Home, BookOpen, Award, User } from "lucide-react";
import { motion } from "framer-motion";
import { cn } from "@/lib/utils";
import { useNavigate, useLocation } from "react-router-dom";

const navItems = [
  { icon: Home, label: "Home", path: "/" },
  { icon: BookOpen, label: "Learn", path: "/learn" },
  { icon: Award, label: "Certs", path: "/certificates" },
  { icon: User, label: "Profile", path: "/profile" },
];

export const BottomNav = () => {
  const location = useLocation();

  return (
    <motion.nav 
      className="fixed bottom-0 left-0 right-0 z-50 px-4 pb-4"
      initial={{ y: 100, opacity: 0 }}
      animate={{ y: 0, opacity: 1 }}
      transition={{ duration: 0.5, delay: 0.6 }}
    >
      <div className="glass-nav rounded-2xl shadow-lg px-2 py-3 max-w-md mx-auto">
        <div className="flex items-center justify-around">
          {navItems.map((item) => (
            <NavItem 
              key={item.label} 
              {...item} 
              active={location.pathname === item.path}
            />
          ))}
        </div>
      </div>
    </motion.nav>
  );
};

interface NavItemProps {
  icon: typeof Home;
  label: string;
  path: string;
  active: boolean;
}

const NavItem = ({ icon: Icon, label, path, active }: NavItemProps) => {
  const navigate = useNavigate();

  return (
    <motion.button
      onClick={() => navigate(path)}
      className={cn(
        "flex flex-col items-center gap-1 px-4 py-2 rounded-xl transition-all duration-300",
        active ? "text-primary" : "text-muted-foreground hover:text-foreground"
      )}
      whileTap={{ scale: 0.9 }}
    >
      <div className="relative">
        <Icon 
          className={cn("w-6 h-6", active && "text-primary")} 
          strokeWidth={active ? 2 : 1.5} 
        />
        {active && (
          <motion.div
            className="absolute -bottom-1.5 left-1/2 -translate-x-1/2 w-1 h-1 rounded-full bg-primary"
            layoutId="activeIndicator"
            initial={{ scale: 0 }}
            animate={{ scale: 1 }}
            transition={{ type: "spring", stiffness: 300, damping: 20 }}
          >
            <div className="absolute inset-0 rounded-full bg-primary animate-ping opacity-75" />
          </motion.div>
        )}
      </div>
      <span className={cn(
        "text-[10px] font-semibold",
        active ? "text-primary" : "text-muted-foreground"
      )}>
        {label}
      </span>
    </motion.button>
  );
};
