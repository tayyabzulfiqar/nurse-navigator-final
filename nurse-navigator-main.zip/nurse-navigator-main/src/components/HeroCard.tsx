import { useEffect, useState } from "react";
import { motion } from "framer-motion";
import { ArrowRight, Shield } from "lucide-react";
import { Button } from "@/components/ui/button";
import { CircularProgress } from "./CircularProgress";
import { supabase } from "@/integrations/supabase/client";
import { useAuth } from "@/contexts/AuthContext";
import { useNavigate } from "react-router-dom";

export const HeroCard = () => {
  const { user } = useAuth();
  const navigate = useNavigate();
  const [overallProgress, setOverallProgress] = useState(0);
  const [nextModuleId, setNextModuleId] = useState<string | null>(null);

  useEffect(() => {
    if (user) {
      calculateProgress();
    }
  }, [user]);

  const calculateProgress = async () => {
    if (!user) return;

    try {
      // Get all mandatory modules
      const { data: mandatoryModules } = await supabase
        .from('training_modules')
        .select('id')
        .eq('is_mandatory', true);

      if (!mandatoryModules?.length) {
        setOverallProgress(100);
        return;
      }

      // Get user's completed mandatory modules
      const { data: userProgress } = await supabase
        .from('user_progress')
        .select('module_id, status, progress_percentage')
        .eq('user_id', user.id);

      const mandatoryIds = mandatoryModules.map(m => m.id);
      const progressMap = new Map(userProgress?.map(p => [p.module_id, p]) || []);

      let totalProgress = 0;
      let firstIncomplete: string | null = null;

      mandatoryIds.forEach(id => {
        const progress = progressMap.get(id);
        if (progress?.status === 'completed') {
          totalProgress += 100;
        } else if (progress?.progress_percentage) {
          totalProgress += progress.progress_percentage;
          if (!firstIncomplete) firstIncomplete = id;
        } else {
          if (!firstIncomplete) firstIncomplete = id;
        }
      });

      const avgProgress = Math.round(totalProgress / mandatoryIds.length);
      setOverallProgress(avgProgress);
      setNextModuleId(firstIncomplete);
    } catch (error) {
      console.error('Error calculating progress:', error);
    }
  };

  const handleResumeClick = () => {
    if (nextModuleId) {
      navigate(`/training/${nextModuleId}`);
    } else {
      navigate('/learn');
    }
  };

  return (
    <motion.div
      className="mx-5 rounded-3xl gradient-hero p-6 overflow-hidden relative glow-primary"
      initial={{ opacity: 0, y: 20, scale: 0.95 }}
      animate={{ opacity: 1, y: 0, scale: 1 }}
      transition={{ duration: 0.6, delay: 0.2 }}
    >
      {/* Decorative elements */}
      <div className="absolute top-0 right-0 w-40 h-40 bg-white/5 rounded-full blur-3xl -translate-y-1/2 translate-x-1/2" />
      <div className="absolute bottom-0 left-0 w-32 h-32 bg-white/5 rounded-full blur-2xl translate-y-1/2 -translate-x-1/2" />
      
      <div className="relative flex items-center justify-between">
        <div className="flex-1">
          <div className="flex items-center gap-2 mb-3">
            <Shield className="w-4 h-4 text-white/80" strokeWidth={1.5} />
            <span className="text-xs font-semibold text-white/80 uppercase tracking-wider">
              Training Status
            </span>
          </div>
          
          <h2 className="text-2xl font-bold text-white mb-1">
            Compliance
          </h2>
          <h2 className="text-2xl font-bold text-white/90 mb-4">
            Readiness
          </h2>
          
          <p className="text-sm text-white/70 mb-5 leading-relaxed">
            {overallProgress === 100 
              ? "All mandatory training complete. Great work!"
              : "Complete your mandatory training to maintain full compliance."}
          </p>
          
          <div className="flex gap-2">
            <Button variant="secondary" size="lg" className="group" onClick={handleResumeClick}>
              {overallProgress === 100 ? 'View Training' : 'Resume'}
              <ArrowRight className="w-4 h-4 transition-transform group-hover:translate-x-1" />
            </Button>
            <Button 
              variant="ghost" 
              size="lg" 
              className="text-white/80 hover:text-white hover:bg-white/10"
              onClick={() => navigate('/dashboard')}
            >
              Dashboard
            </Button>
          </div>
        </div>
        
        <div className="ml-4">
          <CircularProgress progress={overallProgress} />
        </div>
      </div>
    </motion.div>
  );
};
