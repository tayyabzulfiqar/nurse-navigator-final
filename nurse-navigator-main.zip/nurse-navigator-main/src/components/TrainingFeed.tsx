import { useEffect, useState } from "react";
import { motion } from "framer-motion";
import { TrainingCard } from "./TrainingCard";
import { supabase } from "@/integrations/supabase/client";
import { useAuth } from "@/contexts/AuthContext";
import { Loader2 } from "lucide-react";
import { useNavigate } from "react-router-dom";

interface TrainingModule {
  id: string;
  title: string;
  category: string;
  duration_minutes: number | null;
  is_mandatory: boolean | null;
  priority: string | null;
}

interface UserProgress {
  module_id: string;
  status: string | null;
  progress_percentage: number | null;
  due_date: string | null;
}

type CardVariant = "urgent" | "new" | "progress" | "completed";

export const TrainingFeed = () => {
  const { user } = useAuth();
  const navigate = useNavigate();
  const [modules, setModules] = useState<TrainingModule[]>([]);
  const [progressMap, setProgressMap] = useState<Record<string, UserProgress>>({});
  const [loading, setLoading] = useState(true);

  useEffect(() => {
    if (user) {
      fetchData();
    }
  }, [user]);

  const fetchData = async () => {
    if (!user) return;

    try {
      // Fetch all training modules
      const { data: modulesData, error: modulesError } = await supabase
        .from('training_modules')
        .select('*')
        .order('priority', { ascending: false });

      if (modulesError) throw modulesError;

      // Fetch user progress
      const { data: progressData, error: progressError } = await supabase
        .from('user_progress')
        .select('module_id, status, progress_percentage, due_date')
        .eq('user_id', user.id);

      if (progressError) throw progressError;

      setModules(modulesData || []);
      
      // Create a map of module_id -> progress
      const map: Record<string, UserProgress> = {};
      progressData?.forEach(p => {
        map[p.module_id] = p;
      });
      setProgressMap(map);
    } catch (error) {
      console.error('Error fetching training data:', error);
    } finally {
      setLoading(false);
    }
  };

  const getCardVariant = (module: TrainingModule, progress?: UserProgress): CardVariant => {
    if (progress?.status === 'completed') return 'completed';
    if (progress?.status === 'in_progress') return 'progress';
    if (module.priority === 'high' || module.is_mandatory) return 'urgent';
    return 'new';
  };

  const getTag = (module: TrainingModule, progress?: UserProgress): string => {
    if (progress?.status === 'completed') return 'Completed';
    if (progress?.status === 'in_progress') return `${progress.progress_percentage || 0}% Complete`;
    if (module.priority === 'high') return 'High Priority';
    if (module.is_mandatory) return 'Mandatory';
    return 'Not Started';
  };

  // Sort modules: in-progress first, then urgent/mandatory, then new
  const sortedModules = [...modules].sort((a, b) => {
    const progressA = progressMap[a.id];
    const progressB = progressMap[b.id];
    
    // Completed modules go last
    if (progressA?.status === 'completed' && progressB?.status !== 'completed') return 1;
    if (progressB?.status === 'completed' && progressA?.status !== 'completed') return -1;
    
    // In-progress modules first
    if (progressA?.status === 'in_progress' && progressB?.status !== 'in_progress') return -1;
    if (progressB?.status === 'in_progress' && progressA?.status !== 'in_progress') return 1;
    
    // High priority next
    if (a.priority === 'high' && b.priority !== 'high') return -1;
    if (b.priority === 'high' && a.priority !== 'high') return 1;
    
    // Mandatory next
    if (a.is_mandatory && !b.is_mandatory) return -1;
    if (b.is_mandatory && !a.is_mandatory) return 1;
    
    return 0;
  });

  // Show only first 5 for priority view
  const priorityModules = sortedModules.slice(0, 5);

  if (loading) {
    return (
      <section className="px-5 mt-8 pb-28 flex items-center justify-center py-12">
        <Loader2 className="h-6 w-6 animate-spin text-primary" />
      </section>
    );
  }

  return (
    <section className="px-5 mt-8 pb-28">
      <motion.div
        initial={{ opacity: 0, y: 10 }}
        animate={{ opacity: 1, y: 0 }}
        transition={{ duration: 0.4, delay: 0.3 }}
        className="flex items-center justify-between mb-4"
      >
        <h2 className="text-lg font-bold text-foreground">Priority Action Items</h2>
        <button 
          onClick={() => navigate('/learn')}
          className="text-sm font-semibold text-primary hover:text-primary/80 transition-colors"
        >
          View All
        </button>
      </motion.div>
      
      <div className="space-y-3">
        {priorityModules.map((module, index) => {
          const progress = progressMap[module.id];
          return (
            <TrainingCard
              key={module.id}
              id={module.id}
              title={module.title}
              variant={getCardVariant(module, progress)}
              tag={getTag(module, progress)}
              progress={progress?.progress_percentage || undefined}
              duration={`${module.duration_minutes || 30} min`}
              index={index}
            />
          );
        })}
      </div>
    </section>
  );
};
