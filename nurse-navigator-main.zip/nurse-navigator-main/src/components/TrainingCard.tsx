import { motion } from "framer-motion";
import { Clock, AlertTriangle, Sparkles, TrendingUp, ChevronRight, CheckCircle2, Heart } from "lucide-react";
import { cn } from "@/lib/utils";
import { useNavigate } from "react-router-dom";

type CardVariant = "urgent" | "new" | "progress" | "completed";

interface TrainingCardProps {
  id: string;
  title: string;
  variant: CardVariant;
  tag: string;
  progress?: number;
  duration?: string;
  index: number;
  isFavorite?: boolean;
  onToggleFavorite?: (id: string) => void;
}

const variantStyles: Record<CardVariant, {
  icon: typeof AlertTriangle;
  tagBg: string;
  tagText: string;
  iconColor: string;
  accentBorder: string;
}> = {
  urgent: {
    icon: AlertTriangle,
    tagBg: "bg-destructive/10",
    tagText: "text-destructive",
    iconColor: "text-destructive",
    accentBorder: "border-l-destructive",
  },
  new: {
    icon: Sparkles,
    tagBg: "bg-primary/10",
    tagText: "text-primary",
    iconColor: "text-primary",
    accentBorder: "border-l-primary",
  },
  progress: {
    icon: TrendingUp,
    tagBg: "bg-warning/10",
    tagText: "text-warning",
    iconColor: "text-warning",
    accentBorder: "border-l-warning",
  },
  completed: {
    icon: CheckCircle2,
    tagBg: "bg-success/10",
    tagText: "text-success",
    iconColor: "text-success",
    accentBorder: "border-l-success",
  },
};

export const TrainingCard = ({ 
  id,
  title, 
  variant, 
  tag, 
  progress, 
  duration = "15 min",
  index,
  isFavorite = false,
  onToggleFavorite,
}: TrainingCardProps) => {
  const navigate = useNavigate();
  const styles = variantStyles[variant];
  const Icon = styles.icon;

  const handleFavoriteClick = (e: React.MouseEvent) => {
    e.stopPropagation();
    onToggleFavorite?.(id);
  };

  return (
    <motion.div
      onClick={() => navigate(`/training/${id}`)}
      className={cn(
        "card-premium p-4 border-l-4 cursor-pointer",
        "hover:shadow-lg hover:scale-[1.02] transition-all duration-300",
        styles.accentBorder
      )}
      initial={{ opacity: 0, x: -20 }}
      animate={{ opacity: 1, x: 0 }}
      transition={{ duration: 0.4, delay: 0.4 + index * 0.1 }}
      whileHover={{ x: 4 }}
      whileTap={{ scale: 0.98 }}
    >
      <div className="flex items-start justify-between">
        <div className="flex-1">
          <div className="flex items-center gap-2 mb-2">
            <span className={cn(
              "inline-flex items-center gap-1.5 px-2.5 py-1 rounded-full text-xs font-semibold",
              styles.tagBg,
              styles.tagText
            )}>
              <Icon className="w-3 h-3" />
              {tag}
            </span>
          </div>
          
          <h3 className="text-base font-semibold text-foreground mb-1.5">
            {title}
          </h3>
          
          <div className="flex items-center gap-3 text-xs text-muted-foreground">
            <span className="flex items-center gap-1">
              <Clock className="w-3.5 h-3.5" />
              {duration}
            </span>
          </div>
          
          {variant === "progress" && progress !== undefined && (
            <div className="mt-3">
              <div className="flex items-center justify-between mb-1.5">
                <span className="text-xs font-medium text-muted-foreground">Progress</span>
                <span className="text-xs font-semibold text-warning">{progress}%</span>
              </div>
              <div className="h-2 bg-muted rounded-full overflow-hidden">
                <motion.div 
                  className="h-full bg-warning rounded-full"
                  initial={{ width: 0 }}
                  animate={{ width: `${progress}%` }}
                  transition={{ duration: 0.8, delay: 0.6 + index * 0.1 }}
                />
              </div>
            </div>
          )}
        </div>
        
        <div className="flex items-center gap-2">
          {onToggleFavorite && (
            <motion.button
              onClick={handleFavoriteClick}
              className="p-1.5 rounded-full hover:bg-muted transition-colors"
              whileHover={{ scale: 1.1 }}
              whileTap={{ scale: 0.9 }}
            >
              <Heart 
                className={cn(
                  "w-5 h-5 transition-colors",
                  isFavorite ? "fill-red-500 text-red-500" : "text-muted-foreground"
                )} 
              />
            </motion.button>
          )}
          <ChevronRight className="w-5 h-5 text-muted-foreground mt-1" />
        </div>
      </div>
    </motion.div>
  );
};
