import { useState, useEffect } from 'react';
import { useNavigate } from 'react-router-dom';
import { useAuth } from '@/contexts/AuthContext';
import { supabase } from '@/integrations/supabase/client';
import { ArrowLeft, Loader2, TrendingUp, CheckCircle, Clock, AlertTriangle, Calendar, Timer, Award, Target, Footprints, Rocket, BookOpen, Trophy, Crown, GraduationCap } from 'lucide-react';
import { motion } from 'framer-motion';
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import { Progress } from '@/components/ui/progress';
import { PieChart, Pie, Cell, BarChart, Bar, XAxis, YAxis, ResponsiveContainer, Tooltip, LineChart, Line } from 'recharts';
import logo from '@/assets/logo.webp';
import { format, subMonths, startOfMonth, endOfMonth, differenceInDays, isBefore, isAfter, startOfWeek } from 'date-fns';

interface Stats {
  completed: number;
  inProgress: number;
  notStarted: number;
  expired: number;
  totalModules: number;
  totalTimeMinutes: number;
}

interface MonthlyProgress {
  month: string;
  completed: number;
}

interface CategoryStats {
  name: string;
  completed: number;
  total: number;
}

interface UpcomingDeadline {
  id: string;
  title: string;
  dueDate: Date;
  daysLeft: number;
  status: 'urgent' | 'warning' | 'normal';
}

interface Achievement {
  id: string;
  name: string;
  description: string | null;
  icon: string;
  requirement_type: string;
  requirement_value: number;
  earned: boolean;
  earned_at?: string;
  progress: number;
}

interface WeeklyGoal {
  targetModules: number;
  targetMinutes: number;
  completedModules: number;
  completedMinutes: number;
}

export default function Dashboard() {
  const { user } = useAuth();
  const navigate = useNavigate();
  const [loading, setLoading] = useState(true);
  const [stats, setStats] = useState<Stats>({
    completed: 0,
    inProgress: 0,
    notStarted: 0,
    expired: 0,
    totalModules: 0,
    totalTimeMinutes: 0,
  });
  const [monthlyProgress, setMonthlyProgress] = useState<MonthlyProgress[]>([]);
  const [categoryStats, setCategoryStats] = useState<CategoryStats[]>([]);
  const [upcomingDeadlines, setUpcomingDeadlines] = useState<UpcomingDeadline[]>([]);
  const [achievements, setAchievements] = useState<Achievement[]>([]);
  const [weeklyGoal, setWeeklyGoal] = useState<WeeklyGoal>({
    targetModules: 3,
    targetMinutes: 60,
    completedModules: 0,
    completedMinutes: 0,
  });

  useEffect(() => {
    if (user) {
      fetchDashboardData();
    }
  }, [user]);

  const fetchDashboardData = async () => {
    if (!user) return;

    try {
      // Fetch all training modules
      const { data: modules } = await supabase
        .from('training_modules')
        .select('id, category, is_mandatory, title, duration_minutes');

      // Fetch user progress
      const { data: progress } = await supabase
        .from('user_progress')
        .select('module_id, status, completed_at, due_date, progress_percentage')
        .eq('user_id', user.id);

      // Fetch compliance records for expiry info
      const { data: compliance } = await supabase
        .from('compliance_records')
        .select('module_id, expiry_date, is_valid')
        .eq('user_id', user.id);

      if (!modules) return;

      const progressMap = new Map(progress?.map(p => [p.module_id, p]) || []);
      const complianceMap = new Map(compliance?.map(c => [c.module_id, c]) || []);

      // Calculate stats
      let completed = 0;
      let inProgress = 0;
      let notStarted = 0;
      let expired = 0;
      let totalTimeMinutes = 0;

      modules.forEach(module => {
        const p = progressMap.get(module.id);
        const c = complianceMap.get(module.id);

        // Calculate time spent (completed modules contribute full duration, in-progress contribute partial)
        if (p?.status === 'completed') {
          totalTimeMinutes += module.duration_minutes || 30;
        } else if (p?.status === 'in_progress' && p.progress_percentage) {
          totalTimeMinutes += Math.round(((module.duration_minutes || 30) * p.progress_percentage) / 100);
        }

        if (c?.expiry_date && new Date(c.expiry_date) < new Date()) {
          expired++;
        } else if (p?.status === 'completed') {
          completed++;
        } else if (p?.status === 'in_progress') {
          inProgress++;
        } else {
          notStarted++;
        }
      });

      setStats({
        completed,
        inProgress,
        notStarted,
        expired,
        totalModules: modules.length,
        totalTimeMinutes,
      });

      // Calculate upcoming deadlines
      const now = new Date();
      const deadlines: UpcomingDeadline[] = [];
      
      progress?.forEach(p => {
        if (p.due_date && p.status !== 'completed') {
          const dueDate = new Date(p.due_date);
          if (isAfter(dueDate, now)) {
            const daysLeft = differenceInDays(dueDate, now);
            const module = modules.find(m => m.id === p.module_id);
            if (module) {
              deadlines.push({
                id: module.id,
                title: module.title,
                dueDate,
                daysLeft,
                status: daysLeft <= 3 ? 'urgent' : daysLeft <= 7 ? 'warning' : 'normal',
              });
            }
          }
        }
      });

      // Sort by days left and take top 5
      deadlines.sort((a, b) => a.daysLeft - b.daysLeft);
      setUpcomingDeadlines(deadlines.slice(0, 5));

      // Calculate monthly progress (last 6 months)
      const monthlyData: MonthlyProgress[] = [];
      for (let i = 5; i >= 0; i--) {
        const monthDate = subMonths(new Date(), i);
        const monthStart = startOfMonth(monthDate);
        const monthEnd = endOfMonth(monthDate);

        const completedInMonth = progress?.filter(p => {
          if (!p.completed_at) return false;
          const completedDate = new Date(p.completed_at);
          return completedDate >= monthStart && completedDate <= monthEnd;
        }).length || 0;

        monthlyData.push({
          month: format(monthDate, 'MMM'),
          completed: completedInMonth,
        });
      }
      setMonthlyProgress(monthlyData);

      // Calculate category stats
      const categoryMap = new Map<string, { completed: number; total: number }>();
      modules.forEach(module => {
        const category = module.category || 'Other';
        const current = categoryMap.get(category) || { completed: 0, total: 0 };
        current.total++;
        
        const p = progressMap.get(module.id);
        if (p?.status === 'completed') {
          current.completed++;
        }
        
        categoryMap.set(category, current);
      });

      setCategoryStats(
        Array.from(categoryMap.entries()).map(([name, data]) => ({
          name: name.length > 12 ? name.substring(0, 12) + '...' : name,
          ...data,
        }))
      );

      // Fetch achievements
      const { data: allAchievements } = await supabase
        .from('achievements')
        .select('*');

      const { data: userAchievements } = await supabase
        .from('user_achievements')
        .select('achievement_id, earned_at')
        .eq('user_id', user.id);

      const earnedMap = new Map(userAchievements?.map(ua => [ua.achievement_id, ua.earned_at]) || []);

      const achievementsList: Achievement[] = (allAchievements || []).map(a => {
        let currentProgress = 0;
        if (a.requirement_type === 'modules_completed') {
          currentProgress = completed;
        } else if (a.requirement_type === 'time_spent') {
          currentProgress = totalTimeMinutes;
        }

        return {
          id: a.id,
          name: a.name,
          description: a.description,
          icon: a.icon,
          requirement_type: a.requirement_type,
          requirement_value: a.requirement_value,
          earned: earnedMap.has(a.id),
          earned_at: earnedMap.get(a.id),
          progress: Math.min((currentProgress / a.requirement_value) * 100, 100),
        };
      });

      // Check and award new achievements
      for (const achievement of achievementsList) {
        if (!achievement.earned && achievement.progress >= 100) {
          await supabase.from('user_achievements').insert({
            user_id: user.id,
            achievement_id: achievement.id,
          });
          achievement.earned = true;
          achievement.earned_at = new Date().toISOString();
        }
      }

      setAchievements(achievementsList);

      // Calculate weekly goal progress
      const weekStart = startOfWeek(new Date(), { weekStartsOn: 1 });
      
      // Fetch or create weekly goal
      const { data: existingGoal } = await supabase
        .from('weekly_goals')
        .select('*')
        .eq('user_id', user.id)
        .eq('week_start', format(weekStart, 'yyyy-MM-dd'))
        .single();

      let targetModules = 3;
      let targetMinutes = 60;

      if (existingGoal) {
        targetModules = existingGoal.target_modules;
        targetMinutes = existingGoal.target_minutes;
      } else {
        // Create default weekly goal
        await supabase.from('weekly_goals').insert({
          user_id: user.id,
          week_start: format(weekStart, 'yyyy-MM-dd'),
          target_modules: targetModules,
          target_minutes: targetMinutes,
        });
      }

      // Calculate this week's progress
      const weeklyCompleted = progress?.filter(p => {
        if (!p.completed_at) return false;
        const completedDate = new Date(p.completed_at);
        return completedDate >= weekStart;
      }) || [];

      const weeklyMinutes = weeklyCompleted.reduce((sum, p) => {
        const module = modules.find(m => m.id === p.module_id);
        return sum + (module?.duration_minutes || 30);
      }, 0);

      setWeeklyGoal({
        targetModules,
        targetMinutes,
        completedModules: weeklyCompleted.length,
        completedMinutes: weeklyMinutes,
      });
    } catch (error) {
      console.error('Error fetching dashboard data:', error);
    } finally {
      setLoading(false);
    }
  };

  const pieData = [
    { name: 'Completed', value: stats.completed, color: 'hsl(var(--primary))' },
    { name: 'In Progress', value: stats.inProgress, color: 'hsl(var(--chart-2))' },
    { name: 'Not Started', value: stats.notStarted, color: 'hsl(var(--muted))' },
    { name: 'Expired', value: stats.expired, color: 'hsl(var(--destructive))' },
  ].filter(d => d.value > 0);

  const complianceRate = stats.totalModules > 0 
    ? Math.round((stats.completed / stats.totalModules) * 100) 
    : 0;

  const getAchievementIcon = (iconName: string) => {
    const icons: Record<string, React.ReactNode> = {
      'footprints': <Footprints className="w-5 h-5" />,
      'rocket': <Rocket className="w-5 h-5" />,
      'book-open': <BookOpen className="w-5 h-5" />,
      'trophy': <Trophy className="w-5 h-5" />,
      'crown': <Crown className="w-5 h-5" />,
      'clock': <Clock className="w-5 h-5" />,
      'timer': <Timer className="w-5 h-5" />,
      'graduation-cap': <GraduationCap className="w-5 h-5" />,
      'award': <Award className="w-5 h-5" />,
    };
    return icons[iconName] || <Award className="w-5 h-5" />;
  };

  const earnedAchievements = achievements.filter(a => a.earned);
  const upcomingAchievements = achievements.filter(a => !a.earned).sort((a, b) => b.progress - a.progress).slice(0, 3);

  if (loading) {
    return (
      <div className="min-h-screen bg-background flex items-center justify-center">
        <Loader2 className="h-8 w-8 animate-spin text-primary" />
      </div>
    );
  }

  return (
    <div className="min-h-screen bg-background pb-24">
      {/* Header */}
      <div className="gradient-hero px-5 pt-12 pb-20">
        <div className="flex items-center gap-4 mb-6">
          <motion.button
            onClick={() => navigate('/')}
            className="p-2 rounded-xl bg-white/20 backdrop-blur-sm"
            whileHover={{ scale: 1.05 }}
            whileTap={{ scale: 0.95 }}
          >
            <ArrowLeft className="w-5 h-5 text-white" />
          </motion.button>
          <div className="flex-1">
            <img src={logo} alt="Flexible Healthcare" className="h-8 w-auto bg-white rounded-lg px-2 py-1" />
          </div>
        </div>
        <div className="flex items-center gap-3">
          <TrendingUp className="w-8 h-8 text-white" />
          <div>
            <h1 className="text-2xl font-bold text-white">Compliance Dashboard</h1>
            <p className="text-white/80 text-sm">Your training statistics at a glance</p>
          </div>
        </div>
      </div>

      <div className="px-4 -mt-12 max-w-md mx-auto space-y-4">
        {/* Stats Cards */}
        <motion.div
          className="grid grid-cols-2 gap-3"
          initial={{ opacity: 0, y: 20 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ duration: 0.4 }}
        >
          <Card className="bg-card">
            <CardContent className="pt-4 pb-3 px-4">
              <div className="flex items-center gap-2 mb-1">
                <CheckCircle className="w-4 h-4 text-green-500" />
                <span className="text-xs text-muted-foreground">Completed</span>
              </div>
              <p className="text-2xl font-bold text-foreground">{stats.completed}</p>
            </CardContent>
          </Card>
          
          <Card className="bg-card">
            <CardContent className="pt-4 pb-3 px-4">
              <div className="flex items-center gap-2 mb-1">
                <Clock className="w-4 h-4 text-amber-500" />
                <span className="text-xs text-muted-foreground">In Progress</span>
              </div>
              <p className="text-2xl font-bold text-foreground">{stats.inProgress}</p>
            </CardContent>
          </Card>
          
          <Card className="bg-card">
            <CardContent className="pt-4 pb-3 px-4">
              <div className="flex items-center gap-2 mb-1">
                <Timer className="w-4 h-4 text-blue-500" />
                <span className="text-xs text-muted-foreground">Time Spent</span>
              </div>
              <p className="text-2xl font-bold text-foreground">
                {stats.totalTimeMinutes >= 60 
                  ? `${Math.floor(stats.totalTimeMinutes / 60)}h ${stats.totalTimeMinutes % 60}m`
                  : `${stats.totalTimeMinutes}m`
                }
              </p>
            </CardContent>
          </Card>
          
          <Card className="bg-card">
            <CardContent className="pt-4 pb-3 px-4">
              <div className="flex items-center gap-2 mb-1">
                <TrendingUp className="w-4 h-4 text-primary" />
                <span className="text-xs text-muted-foreground">Compliance</span>
              </div>
              <p className="text-2xl font-bold text-foreground">{complianceRate}%</p>
            </CardContent>
          </Card>
        </motion.div>

        {/* Weekly Goals Tracker */}
        <motion.div
          initial={{ opacity: 0, y: 20 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ duration: 0.4, delay: 0.05 }}
        >
          <Card>
            <CardHeader className="pb-2">
              <CardTitle className="text-base font-semibold flex items-center gap-2">
                <Target className="w-4 h-4" />
                Weekly Goals
              </CardTitle>
            </CardHeader>
            <CardContent className="space-y-4">
              <div>
                <div className="flex justify-between items-center mb-2">
                  <span className="text-sm text-muted-foreground">Modules Completed</span>
                  <span className="text-sm font-medium">
                    {weeklyGoal.completedModules} / {weeklyGoal.targetModules}
                  </span>
                </div>
                <Progress 
                  value={Math.min((weeklyGoal.completedModules / weeklyGoal.targetModules) * 100, 100)} 
                  className="h-2"
                />
              </div>
              <div>
                <div className="flex justify-between items-center mb-2">
                  <span className="text-sm text-muted-foreground">Training Time</span>
                  <span className="text-sm font-medium">
                    {weeklyGoal.completedMinutes}m / {weeklyGoal.targetMinutes}m
                  </span>
                </div>
                <Progress 
                  value={Math.min((weeklyGoal.completedMinutes / weeklyGoal.targetMinutes) * 100, 100)} 
                  className="h-2"
                />
              </div>
              {weeklyGoal.completedModules >= weeklyGoal.targetModules && 
               weeklyGoal.completedMinutes >= weeklyGoal.targetMinutes && (
                <div className="flex items-center gap-2 p-3 rounded-lg bg-primary/10 text-primary">
                  <CheckCircle className="w-4 h-4" />
                  <span className="text-sm font-medium">Weekly goals achieved!</span>
                </div>
              )}
            </CardContent>
          </Card>
        </motion.div>

        {/* Achievement Badges */}
        <motion.div
          initial={{ opacity: 0, y: 20 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ duration: 0.4, delay: 0.1 }}
        >
          <Card>
            <CardHeader className="pb-2">
              <CardTitle className="text-base font-semibold flex items-center gap-2">
                <Award className="w-4 h-4" />
                Achievements ({earnedAchievements.length}/{achievements.length})
              </CardTitle>
            </CardHeader>
            <CardContent>
              {/* Earned Badges */}
              {earnedAchievements.length > 0 && (
                <div className="mb-4">
                  <p className="text-xs text-muted-foreground mb-2">Earned</p>
                  <div className="flex flex-wrap gap-2">
                    {earnedAchievements.map((achievement) => (
                      <div
                        key={achievement.id}
                        className="flex items-center gap-2 px-3 py-2 rounded-full bg-primary/10 text-primary"
                        title={achievement.description || achievement.name}
                      >
                        {getAchievementIcon(achievement.icon)}
                        <span className="text-xs font-medium">{achievement.name}</span>
                      </div>
                    ))}
                  </div>
                </div>
              )}

              {/* Upcoming Achievements */}
              {upcomingAchievements.length > 0 && (
                <div>
                  <p className="text-xs text-muted-foreground mb-2">In Progress</p>
                  <div className="space-y-3">
                    {upcomingAchievements.map((achievement) => (
                      <div key={achievement.id} className="flex items-center gap-3">
                        <div className="p-2 rounded-full bg-muted text-muted-foreground">
                          {getAchievementIcon(achievement.icon)}
                        </div>
                        <div className="flex-1 min-w-0">
                          <p className="text-sm font-medium truncate">{achievement.name}</p>
                          <Progress value={achievement.progress} className="h-1.5 mt-1" />
                        </div>
                        <span className="text-xs text-muted-foreground">{Math.round(achievement.progress)}%</span>
                      </div>
                    ))}
                  </div>
                </div>
              )}

              {achievements.length === 0 && (
                <p className="text-center text-muted-foreground py-4">No achievements available</p>
              )}
            </CardContent>
          </Card>
        </motion.div>

        {/* Upcoming Deadlines */}
        {upcomingDeadlines.length > 0 && (
          <motion.div
            initial={{ opacity: 0, y: 20 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ duration: 0.4, delay: 0.05 }}
          >
            <Card>
              <CardHeader className="pb-2">
                <CardTitle className="text-base font-semibold flex items-center gap-2">
                  <Calendar className="w-4 h-4" />
                  Upcoming Deadlines
                </CardTitle>
              </CardHeader>
              <CardContent className="space-y-2">
                {upcomingDeadlines.map((deadline) => (
                  <div 
                    key={deadline.id}
                    className="flex items-center justify-between p-3 rounded-lg bg-muted/50"
                    onClick={() => navigate(`/training/${deadline.id}`)}
                  >
                    <div className="flex-1 min-w-0">
                      <p className="text-sm font-medium text-foreground truncate">{deadline.title}</p>
                      <p className="text-xs text-muted-foreground">
                        Due {format(deadline.dueDate, 'MMM d, yyyy')}
                      </p>
                    </div>
                    <div className={`
                      px-2 py-1 rounded-full text-xs font-medium
                      ${deadline.status === 'urgent' ? 'bg-destructive/20 text-destructive' : ''}
                      ${deadline.status === 'warning' ? 'bg-amber-500/20 text-amber-600' : ''}
                      ${deadline.status === 'normal' ? 'bg-primary/20 text-primary' : ''}
                    `}>
                      {deadline.daysLeft === 0 ? 'Today' : 
                       deadline.daysLeft === 1 ? '1 day' : 
                       `${deadline.daysLeft} days`}
                    </div>
                  </div>
                ))}
              </CardContent>
            </Card>
          </motion.div>
        )}

        {/* Expired Training Alert */}
        {stats.expired > 0 && (
          <motion.div
            initial={{ opacity: 0, y: 20 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ duration: 0.4, delay: 0.1 }}
          >
            <Card className="border-destructive/50 bg-destructive/5">
              <CardContent className="pt-4 pb-4 px-4">
                <div className="flex items-center gap-3">
                  <AlertTriangle className="w-5 h-5 text-destructive" />
                  <div>
                    <p className="text-sm font-medium text-destructive">Expired Training</p>
                    <p className="text-xs text-muted-foreground">
                      You have {stats.expired} expired training module{stats.expired > 1 ? 's' : ''} that need renewal
                    </p>
                  </div>
                </div>
              </CardContent>
            </Card>
          </motion.div>
        )}

        {/* Training Status Pie Chart */}
        <motion.div
          initial={{ opacity: 0, y: 20 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ duration: 0.4, delay: 0.1 }}
        >
          <Card>
            <CardHeader className="pb-2">
              <CardTitle className="text-base font-semibold">Training Status</CardTitle>
            </CardHeader>
            <CardContent>
              {pieData.length > 0 ? (
                <div className="h-48">
                  <ResponsiveContainer width="100%" height="100%">
                    <PieChart>
                      <Pie
                        data={pieData}
                        cx="50%"
                        cy="50%"
                        innerRadius={40}
                        outerRadius={70}
                        paddingAngle={2}
                        dataKey="value"
                      >
                        {pieData.map((entry, index) => (
                          <Cell key={`cell-${index}`} fill={entry.color} />
                        ))}
                      </Pie>
                      <Tooltip 
                        contentStyle={{ 
                          backgroundColor: 'hsl(var(--card))', 
                          border: '1px solid hsl(var(--border))',
                          borderRadius: '8px',
                        }}
                      />
                    </PieChart>
                  </ResponsiveContainer>
                </div>
              ) : (
                <p className="text-center text-muted-foreground py-8">No data available</p>
              )}
              <div className="flex flex-wrap justify-center gap-3 mt-2">
                {pieData.map((entry) => (
                  <div key={entry.name} className="flex items-center gap-1.5">
                    <div 
                      className="w-2.5 h-2.5 rounded-full" 
                      style={{ backgroundColor: entry.color }}
                    />
                    <span className="text-xs text-muted-foreground">{entry.name}</span>
                  </div>
                ))}
              </div>
            </CardContent>
          </Card>
        </motion.div>

        {/* Monthly Progress Line Chart */}
        <motion.div
          initial={{ opacity: 0, y: 20 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ duration: 0.4, delay: 0.2 }}
        >
          <Card>
            <CardHeader className="pb-2">
              <CardTitle className="text-base font-semibold">Monthly Completions</CardTitle>
            </CardHeader>
            <CardContent>
              <div className="h-48">
                <ResponsiveContainer width="100%" height="100%">
                  <LineChart data={monthlyProgress}>
                    <XAxis 
                      dataKey="month" 
                      axisLine={false}
                      tickLine={false}
                      tick={{ fontSize: 11, fill: 'hsl(var(--muted-foreground))' }}
                    />
                    <YAxis 
                      axisLine={false}
                      tickLine={false}
                      tick={{ fontSize: 11, fill: 'hsl(var(--muted-foreground))' }}
                      allowDecimals={false}
                    />
                    <Tooltip 
                      contentStyle={{ 
                        backgroundColor: 'hsl(var(--card))', 
                        border: '1px solid hsl(var(--border))',
                        borderRadius: '8px',
                      }}
                    />
                    <Line 
                      type="monotone" 
                      dataKey="completed" 
                      stroke="hsl(var(--primary))"
                      strokeWidth={2}
                      dot={{ fill: 'hsl(var(--primary))', strokeWidth: 0 }}
                    />
                  </LineChart>
                </ResponsiveContainer>
              </div>
            </CardContent>
          </Card>
        </motion.div>

        {/* Category Progress Bar Chart */}
        <motion.div
          initial={{ opacity: 0, y: 20 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ duration: 0.4, delay: 0.3 }}
        >
          <Card>
            <CardHeader className="pb-2">
              <CardTitle className="text-base font-semibold">Progress by Category</CardTitle>
            </CardHeader>
            <CardContent>
              {categoryStats.length > 0 ? (
                <div className="h-52">
                  <ResponsiveContainer width="100%" height="100%">
                    <BarChart data={categoryStats} layout="vertical">
                      <XAxis 
                        type="number"
                        axisLine={false}
                        tickLine={false}
                        tick={{ fontSize: 10, fill: 'hsl(var(--muted-foreground))' }}
                      />
                      <YAxis 
                        type="category"
                        dataKey="name"
                        axisLine={false}
                        tickLine={false}
                        tick={{ fontSize: 10, fill: 'hsl(var(--muted-foreground))' }}
                        width={80}
                      />
                      <Tooltip 
                        contentStyle={{ 
                          backgroundColor: 'hsl(var(--card))', 
                          border: '1px solid hsl(var(--border))',
                          borderRadius: '8px',
                        }}
                      />
                      <Bar 
                        dataKey="total" 
                        fill="hsl(var(--muted))" 
                        radius={[0, 4, 4, 0]}
                        name="Total"
                      />
                      <Bar 
                        dataKey="completed" 
                        fill="hsl(var(--primary))" 
                        radius={[0, 4, 4, 0]}
                        name="Completed"
                      />
                    </BarChart>
                  </ResponsiveContainer>
                </div>
              ) : (
                <p className="text-center text-muted-foreground py-8">No data available</p>
              )}
            </CardContent>
          </Card>
        </motion.div>
      </div>
    </div>
  );
}
