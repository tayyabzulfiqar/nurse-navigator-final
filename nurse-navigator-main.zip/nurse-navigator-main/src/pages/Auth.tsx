import { useEffect } from 'react';
import { useNavigate } from 'react-router-dom';
import { useAuth } from '@/contexts/AuthContext';
import { BackgroundSlider } from '@/components/BackgroundSlider';
import { AuthForm } from '@/components/AuthForm';
import { Shield } from 'lucide-react';
import { motion } from 'framer-motion';
import logo from '@/assets/logo.webp';

/**
 * Auth Page
 * Features:
 * - Background image slider with healthcare images
 * - Glassmorphism login card
 * - Connected to Supabase via AuthContext
 */

export default function Auth() {
  const { user } = useAuth();
  const navigate = useNavigate();

  // Redirect authenticated users to home
  useEffect(() => {
    if (user) {
      navigate('/');
    }
  }, [user, navigate]);

  return (
    <div className="min-h-screen relative flex flex-col items-center justify-center p-4">
      {/* Background Image Slider with overlay */}
      <BackgroundSlider />

      {/* Content */}
      <div className="relative z-10 w-full max-w-md">
        {/* Logo and Header */}
        <motion.div 
          className="text-center mb-8"
          initial={{ opacity: 0, y: -20 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ duration: 0.6 }}
        >
          <div className="inline-flex items-center justify-center mb-6">
            <div className="bg-white rounded-2xl p-3 shadow-2xl">
              <img src={logo} alt="Flexible Healthcare" className="h-14 w-auto" />
            </div>
          </div>
          <h1 className="text-3xl font-bold text-white mb-2 drop-shadow-lg">
            Training Portal
          </h1>
          <p className="text-white/80 text-sm drop-shadow">
            Your professional development hub
          </p>
        </motion.div>

        {/* Glassmorphism Auth Card with 1px white border at 20% opacity */}
        <motion.div
          className="backdrop-blur-xl bg-white/15 rounded-3xl shadow-2xl p-8"
          initial={{ opacity: 0, y: 20, scale: 0.95 }}
          animate={{ opacity: 1, y: 0, scale: 1 }}
          transition={{ duration: 0.6, delay: 0.2 }}
          style={{
            border: '1px solid rgba(255, 255, 255, 0.2)',
            boxShadow: '0 25px 50px -12px rgba(0, 0, 0, 0.4), inset 0 1px 1px rgba(255, 255, 255, 0.15)',
          }}
        >
          {/* AuthForm component handles Supabase authentication */}
          <AuthForm />
        </motion.div>

        {/* Trust Badges */}
        <motion.div 
          className="flex items-center justify-center gap-4 mt-8"
          initial={{ opacity: 0 }}
          animate={{ opacity: 1 }}
          transition={{ duration: 0.6, delay: 0.4 }}
        >
          <div className="flex items-center gap-1.5 text-xs text-white/80">
            <Shield className="w-4 h-4" />
            <span>Secure</span>
          </div>
          <div className="w-1 h-1 rounded-full bg-white/40" />
          <span className="text-xs text-white/80">NHS Compliant</span>
          <div className="w-1 h-1 rounded-full bg-white/40" />
          <span className="text-xs text-white/80">GDPR Ready</span>
        </motion.div>
      </div>
    </div>
  );
}
