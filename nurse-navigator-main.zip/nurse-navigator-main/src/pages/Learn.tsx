import { useEffect, useState } from 'react';
import { useNavigate } from 'react-router-dom';
import { supabase } from '@/integrations/supabase/client';
import { useAuth } from '@/contexts/AuthContext';
import { TrainingCard } from '@/components/TrainingCard';
import { BottomNav } from '@/components/BottomNav';
import { ArrowLeft, Loader2, Search, Heart, Filter, CheckCircle, Clock, AlertTriangle, ArrowUpDown } from 'lucide-react';
import { motion } from 'framer-motion';
import { Input } from '@/components/ui/input';
import { useToast } from '@/hooks/use-toast';
import logo from '@/assets/logo.webp';

interface TrainingModule {
  id: string;
  title: string;
  category: string;
  duration_minutes: number | null;
  is_mandatory: boolean | null;
  priority: string | null;
}

interface UserProgress {
  module_id: string;
  status: string | null;
  progress_percentage: number | null;
  due_date: string | null;
}

type CardVariant = "urgent" | "new" | "progress" | "completed";
type FilterType = 'all' | 'favorites' | string;
type StatusFilter = 'all' | 'completed' | 'in_progress' | 'not_started';
type PriorityFilter = 'all' | 'high' | 'mandatory';
type SortOption = 'name' | 'duration' | 'due_date' | 'priority';

export default function Learn() {
  const { user } = useAuth();
  const navigate = useNavigate();
  const { toast } = useToast();
  const [modules, setModules] = useState<TrainingModule[]>([]);
  const [progressMap, setProgressMap] = useState<Record<string, UserProgress>>({});
  const [favorites, setFavorites] = useState<Set<string>>(new Set());
  const [loading, setLoading] = useState(true);
  const [searchQuery, setSearchQuery] = useState('');
  const [selectedFilter, setSelectedFilter] = useState<FilterType>('all');
  const [statusFilter, setStatusFilter] = useState<StatusFilter>('all');
  const [priorityFilter, setPriorityFilter] = useState<PriorityFilter>('all');
  const [showFilters, setShowFilters] = useState(false);
  const [sortBy, setSortBy] = useState<SortOption>('name');
  const [sortAsc, setSortAsc] = useState(true);

  useEffect(() => {
    if (user) {
      fetchData();
    }
  }, [user]);

  const fetchData = async () => {
    if (!user) return;

    try {
      // Fetch modules
      const { data: modulesData } = await supabase
        .from('training_modules')
        .select('*')
        .order('category');

      // Fetch user progress
      const { data: progressData } = await supabase
        .from('user_progress')
        .select('module_id, status, progress_percentage, due_date')
        .eq('user_id', user.id);

      // Fetch favorites
      const { data: favoritesData } = await supabase
        .from('user_favorites')
        .select('module_id')
        .eq('user_id', user.id);

      setModules(modulesData || []);

      const map: Record<string, UserProgress> = {};
      progressData?.forEach(p => {
        map[p.module_id] = p;
      });
      setProgressMap(map);

      const favSet = new Set<string>();
      favoritesData?.forEach(f => favSet.add(f.module_id));
      setFavorites(favSet);
    } catch (error) {
      console.error('Error fetching data:', error);
    } finally {
      setLoading(false);
    }
  };

  const toggleFavorite = async (moduleId: string) => {
    if (!user) return;

    const isFavorite = favorites.has(moduleId);

    try {
      if (isFavorite) {
        // Remove from favorites
        await supabase
          .from('user_favorites')
          .delete()
          .eq('user_id', user.id)
          .eq('module_id', moduleId);

        setFavorites(prev => {
          const next = new Set(prev);
          next.delete(moduleId);
          return next;
        });

        toast({
          title: 'Removed from favorites',
          description: 'Training module removed from your favorites.',
        });
      } else {
        // Add to favorites
        await supabase
          .from('user_favorites')
          .insert({ user_id: user.id, module_id: moduleId });

        setFavorites(prev => new Set(prev).add(moduleId));

        toast({
          title: 'Added to favorites',
          description: 'Training module added to your favorites.',
        });
      }
    } catch (error) {
      console.error('Error toggling favorite:', error);
      toast({
        title: 'Error',
        description: 'Could not update favorites. Please try again.',
        variant: 'destructive',
      });
    }
  };

  const getCardVariant = (module: TrainingModule, progress?: UserProgress): CardVariant => {
    if (progress?.status === 'completed') return 'completed';
    if (progress?.status === 'in_progress') return 'progress';
    if (module.priority === 'high' || module.is_mandatory) return 'urgent';
    return 'new';
  };

  const getTag = (module: TrainingModule, progress?: UserProgress): string => {
    if (progress?.status === 'completed') return 'Completed';
    if (progress?.status === 'in_progress') return `${progress.progress_percentage || 0}% Complete`;
    if (module.priority === 'high') return 'High Priority';
    if (module.is_mandatory) return 'Mandatory';
    return 'Not Started';
  };

  // Get unique categories
  const categories = [...new Set(modules.map(m => m.category))];

  // Filter modules
  const filteredModules = modules.filter(module => {
    const matchesSearch = module.title.toLowerCase().includes(searchQuery.toLowerCase());
    const progress = progressMap[module.id];
    
    // Category/Favorites filter
    let matchesCategory = true;
    if (selectedFilter === 'favorites') matchesCategory = favorites.has(module.id);
    else if (selectedFilter !== 'all') matchesCategory = module.category === selectedFilter;
    
    // Status filter
    let matchesStatus = true;
    if (statusFilter === 'completed') matchesStatus = progress?.status === 'completed';
    else if (statusFilter === 'in_progress') matchesStatus = progress?.status === 'in_progress';
    else if (statusFilter === 'not_started') matchesStatus = !progress || progress.status === 'not_started';
    
    // Priority filter
    let matchesPriority = true;
    if (priorityFilter === 'high') matchesPriority = module.priority === 'high';
    else if (priorityFilter === 'mandatory') matchesPriority = module.is_mandatory === true;
    
    return matchesSearch && matchesCategory && matchesStatus && matchesPriority;
  });

  // Sort modules
  const sortedModules = [...filteredModules].sort((a, b) => {
    let comparison = 0;
    
    switch (sortBy) {
      case 'name':
        comparison = a.title.localeCompare(b.title);
        break;
      case 'duration':
        comparison = (a.duration_minutes || 0) - (b.duration_minutes || 0);
        break;
      case 'due_date':
        const dateA = progressMap[a.id]?.due_date ? new Date(progressMap[a.id].due_date!).getTime() : Infinity;
        const dateB = progressMap[b.id]?.due_date ? new Date(progressMap[b.id].due_date!).getTime() : Infinity;
        comparison = dateA - dateB;
        break;
      case 'priority':
        const priorityOrder: Record<string, number> = { high: 0, normal: 1, low: 2 };
        const prioA = a.is_mandatory ? -1 : (priorityOrder[a.priority || 'normal'] ?? 1);
        const prioB = b.is_mandatory ? -1 : (priorityOrder[b.priority || 'normal'] ?? 1);
        comparison = prioA - prioB;
        break;
    }
    
    return sortAsc ? comparison : -comparison;
  });

  const handleSort = (option: SortOption) => {
    if (sortBy === option) {
      setSortAsc(!sortAsc);
    } else {
      setSortBy(option);
      setSortAsc(true);
    }
  };

  if (loading) {
    return (
      <div className="min-h-screen bg-background flex items-center justify-center">
        <Loader2 className="h-8 w-8 animate-spin text-primary" />
      </div>
    );
  }

  return (
    <div className="min-h-screen bg-background pb-24">
      {/* Header */}
      <div className="gradient-hero px-5 pt-12 pb-8">
        <div className="flex items-center gap-4 mb-6">
          <motion.button
            onClick={() => navigate('/')}
            className="p-2 rounded-xl bg-white/20 backdrop-blur-sm"
            whileHover={{ scale: 1.05 }}
            whileTap={{ scale: 0.95 }}
          >
            <ArrowLeft className="w-5 h-5 text-white" />
          </motion.button>
          <div className="flex-1">
            <img src={logo} alt="Flexible Healthcare" className="h-8 w-auto bg-white rounded-lg px-2 py-1" />
          </div>
        </div>
        <h1 className="text-2xl font-bold text-white mb-2">All Training</h1>
        <p className="text-white/80 text-sm">{modules.length} modules available</p>
      </div>

      {/* Search & Filters */}
      <div className="px-4 -mt-4">
        <div className="bg-card rounded-2xl shadow-lg p-4 max-w-md mx-auto">
          <div className="flex gap-2 mb-4">
            <div className="relative flex-1">
              <Search className="absolute left-3 top-1/2 -translate-y-1/2 w-4 h-4 text-muted-foreground" />
              <Input
                placeholder="Search training..."
                value={searchQuery}
                onChange={(e) => setSearchQuery(e.target.value)}
                className="pl-10"
              />
            </div>
            <button
              onClick={() => setShowFilters(!showFilters)}
              className={`p-2.5 rounded-lg transition-colors ${
                showFilters || statusFilter !== 'all' || priorityFilter !== 'all'
                  ? 'bg-primary text-primary-foreground'
                  : 'bg-muted text-muted-foreground hover:bg-muted/80'
              }`}
            >
              <Filter className="w-4 h-4" />
            </button>
          </div>

          {/* Advanced Filters */}
          {showFilters && (
            <motion.div
              initial={{ opacity: 0, height: 0 }}
              animate={{ opacity: 1, height: 'auto' }}
              exit={{ opacity: 0, height: 0 }}
              className="mb-4 space-y-3"
            >
              {/* Status Filter */}
              <div>
                <p className="text-xs font-medium text-muted-foreground mb-2">Status</p>
                <div className="flex gap-2 flex-wrap">
                  {[
                    { value: 'all', label: 'All', icon: null },
                    { value: 'completed', label: 'Completed', icon: CheckCircle },
                    { value: 'in_progress', label: 'In Progress', icon: Clock },
                    { value: 'not_started', label: 'Not Started', icon: null },
                  ].map(({ value, label, icon: Icon }) => (
                    <button
                      key={value}
                      onClick={() => setStatusFilter(value as StatusFilter)}
                      className={`px-3 py-1.5 rounded-full text-xs font-semibold whitespace-nowrap transition-colors flex items-center gap-1 ${
                        statusFilter === value
                          ? 'bg-primary text-primary-foreground'
                          : 'bg-muted text-muted-foreground hover:bg-muted/80'
                      }`}
                    >
                      {Icon && <Icon className="w-3 h-3" />}
                      {label}
                    </button>
                  ))}
                </div>
              </div>

              {/* Priority Filter */}
              <div>
                <p className="text-xs font-medium text-muted-foreground mb-2">Priority</p>
                <div className="flex gap-2 flex-wrap">
                  {[
                    { value: 'all', label: 'All' },
                    { value: 'high', label: 'High Priority' },
                    { value: 'mandatory', label: 'Mandatory' },
                  ].map(({ value, label }) => (
                    <button
                      key={value}
                      onClick={() => setPriorityFilter(value as PriorityFilter)}
                      className={`px-3 py-1.5 rounded-full text-xs font-semibold whitespace-nowrap transition-colors flex items-center gap-1 ${
                        priorityFilter === value
                          ? 'bg-primary text-primary-foreground'
                          : 'bg-muted text-muted-foreground hover:bg-muted/80'
                      }`}
                    >
                      {value !== 'all' && <AlertTriangle className="w-3 h-3" />}
                      {label}
                    </button>
                  ))}
                </div>
              </div>

              {/* Sort Options */}
              <div>
                <p className="text-xs font-medium text-muted-foreground mb-2">Sort By</p>
                <div className="flex gap-2 flex-wrap">
                  {[
                    { value: 'name', label: 'Name' },
                    { value: 'duration', label: 'Duration' },
                    { value: 'due_date', label: 'Due Date' },
                    { value: 'priority', label: 'Priority' },
                  ].map(({ value, label }) => (
                    <button
                      key={value}
                      onClick={() => handleSort(value as SortOption)}
                      className={`px-3 py-1.5 rounded-full text-xs font-semibold whitespace-nowrap transition-colors flex items-center gap-1 ${
                        sortBy === value
                          ? 'bg-primary text-primary-foreground'
                          : 'bg-muted text-muted-foreground hover:bg-muted/80'
                      }`}
                    >
                      {label}
                      {sortBy === value && (
                        <ArrowUpDown className={`w-3 h-3 ${!sortAsc ? 'rotate-180' : ''}`} />
                      )}
                    </button>
                  ))}
                </div>
              </div>
            </motion.div>
          )}
          
          {/* Category Filter */}
          <div className="flex gap-2 overflow-x-auto pb-1">
            <button
              onClick={() => setSelectedFilter('all')}
              className={`px-3 py-1.5 rounded-full text-xs font-semibold whitespace-nowrap transition-colors ${
                selectedFilter === 'all' 
                  ? 'bg-primary text-primary-foreground' 
                  : 'bg-muted text-muted-foreground hover:bg-muted/80'
              }`}
            >
              All
            </button>
            <button
              onClick={() => setSelectedFilter('favorites')}
              className={`px-3 py-1.5 rounded-full text-xs font-semibold whitespace-nowrap transition-colors flex items-center gap-1 ${
                selectedFilter === 'favorites' 
                  ? 'bg-primary text-primary-foreground' 
                  : 'bg-muted text-muted-foreground hover:bg-muted/80'
              }`}
            >
              <Heart className="w-3 h-3" />
              Favorites ({favorites.size})
            </button>
            {categories.map(category => (
              <button
                key={category}
                onClick={() => setSelectedFilter(category)}
                className={`px-3 py-1.5 rounded-full text-xs font-semibold whitespace-nowrap transition-colors ${
                  selectedFilter === category 
                    ? 'bg-primary text-primary-foreground' 
                    : 'bg-muted text-muted-foreground hover:bg-muted/80'
                }`}
              >
                {category}
              </button>
            ))}
          </div>
        </div>
      </div>

      {/* Module List */}
      <div className="px-4 mt-6 max-w-md mx-auto space-y-3">
        {sortedModules.map((module, index) => {
          const progress = progressMap[module.id];
          return (
            <TrainingCard
              key={module.id}
              id={module.id}
              title={module.title}
              variant={getCardVariant(module, progress)}
              tag={getTag(module, progress)}
              progress={progress?.progress_percentage || undefined}
              duration={`${module.duration_minutes || 30} min`}
              index={index}
              isFavorite={favorites.has(module.id)}
              onToggleFavorite={toggleFavorite}
            />
          );
        })}
        
        {sortedModules.length === 0 && (
          <div className="text-center py-8 text-muted-foreground">
            {selectedFilter === 'favorites' 
              ? 'No favorite modules yet. Tap the heart icon to add some!'
              : 'No training modules found.'}
          </div>
        )}
      </div>

      <BottomNav />
    </div>
  );
}
