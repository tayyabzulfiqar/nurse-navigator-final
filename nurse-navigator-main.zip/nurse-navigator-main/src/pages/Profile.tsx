import { useState, useEffect, useRef } from 'react';
import { useNavigate } from 'react-router-dom';
import { useAuth } from '@/contexts/AuthContext';
import { supabase } from '@/integrations/supabase/client';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { Label } from '@/components/ui/label';
import { Switch } from '@/components/ui/switch';
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from '@/components/ui/select';
import { Separator } from '@/components/ui/separator';
import { useToast } from '@/hooks/use-toast';
import { ProfileCompletionIndicator } from '@/components/ProfileCompletionIndicator';
import { ArrowLeft, Loader2, Save, Camera, Bell, Target } from 'lucide-react';
import { format, startOfWeek } from 'date-fns';
import { motion } from 'framer-motion';
import logo from '@/assets/logo.webp';

interface Profile {
  first_name: string | null;
  last_name: string | null;
  department: string | null;
  job_title: string | null;
  avatar_url: string | null;
  email_training_reminders: boolean;
  email_deadline_alerts: boolean;
  email_completion_summary: boolean;
  reminder_days_before: number;
}

interface WeeklyGoals {
  target_modules: number;
  target_minutes: number;
}

export default function Profile() {
  const { user } = useAuth();
  const navigate = useNavigate();
  const { toast } = useToast();
  
  const [loading, setLoading] = useState(true);
  const [saving, setSaving] = useState(false);
  const [uploading, setUploading] = useState(false);
  const fileInputRef = useRef<HTMLInputElement>(null);
  const [profile, setProfile] = useState<Profile>({
    first_name: '',
    last_name: '',
    department: '',
    job_title: '',
    avatar_url: null,
    email_training_reminders: true,
    email_deadline_alerts: true,
    email_completion_summary: false,
    reminder_days_before: 3,
  });
  const [weeklyGoals, setWeeklyGoals] = useState<WeeklyGoals>({
    target_modules: 3,
    target_minutes: 60,
  });

  useEffect(() => {
    if (user) {
      fetchProfile();
      fetchWeeklyGoals();
    }
  }, [user]);

  const fetchProfile = async () => {
    if (!user) return;
    
    try {
      const { data, error } = await supabase
        .from('profiles')
        .select('first_name, last_name, department, job_title, avatar_url, email_training_reminders, email_deadline_alerts, email_completion_summary, reminder_days_before')
        .eq('user_id', user.id)
        .maybeSingle();

      if (error) throw error;

      if (data) {
        setProfile({
          first_name: data.first_name || '',
          last_name: data.last_name || '',
          department: data.department || '',
          job_title: data.job_title || '',
          avatar_url: data.avatar_url,
          email_training_reminders: data.email_training_reminders ?? true,
          email_deadline_alerts: data.email_deadline_alerts ?? true,
          email_completion_summary: data.email_completion_summary ?? false,
          reminder_days_before: data.reminder_days_before ?? 3,
        });
      }
    } catch (error) {
      console.error('Error fetching profile:', error);
    } finally {
      setLoading(false);
    }
  };

  const fetchWeeklyGoals = async () => {
    if (!user) return;

    try {
      const weekStart = startOfWeek(new Date(), { weekStartsOn: 1 });
      const { data } = await supabase
        .from('weekly_goals')
        .select('target_modules, target_minutes')
        .eq('user_id', user.id)
        .eq('week_start', format(weekStart, 'yyyy-MM-dd'))
        .maybeSingle();

      if (data) {
        setWeeklyGoals({
          target_modules: data.target_modules,
          target_minutes: data.target_minutes,
        });
      }
    } catch (error) {
      console.error('Error fetching weekly goals:', error);
    }
  };

  const saveWeeklyGoals = async () => {
    if (!user) return;

    try {
      const weekStart = startOfWeek(new Date(), { weekStartsOn: 1 });
      
      const { error } = await supabase
        .from('weekly_goals')
        .upsert({
          user_id: user.id,
          week_start: format(weekStart, 'yyyy-MM-dd'),
          target_modules: weeklyGoals.target_modules,
          target_minutes: weeklyGoals.target_minutes,
        }, {
          onConflict: 'user_id,week_start',
        });

      if (error) throw error;
    } catch (error) {
      console.error('Error saving weekly goals:', error);
      throw error;
    }
  };

  const handleAvatarUpload = async (event: React.ChangeEvent<HTMLInputElement>) => {
    if (!user || !event.target.files || event.target.files.length === 0) return;

    const file = event.target.files[0];
    const fileExt = file.name.split('.').pop();
    const filePath = `${user.id}/avatar.${fileExt}`;

    setUploading(true);
    try {
      // Upload to storage
      const { error: uploadError } = await supabase.storage
        .from('avatars')
        .upload(filePath, file, { upsert: true });

      if (uploadError) throw uploadError;

      // Get public URL
      const { data: urlData } = supabase.storage
        .from('avatars')
        .getPublicUrl(filePath);

      const avatarUrl = `${urlData.publicUrl}?t=${Date.now()}`;

      // Update profile
      const { error: updateError } = await supabase
        .from('profiles')
        .update({ avatar_url: avatarUrl })
        .eq('user_id', user.id);

      if (updateError) throw updateError;

      setProfile(prev => ({ ...prev, avatar_url: avatarUrl }));
      toast({
        title: 'Avatar updated',
        description: 'Your profile picture has been updated.',
      });
    } catch (error) {
      console.error('Error uploading avatar:', error);
      toast({
        title: 'Upload failed',
        description: 'Could not upload avatar. Please try again.',
        variant: 'destructive',
      });
    } finally {
      setUploading(false);
    }
  };

  const handleSave = async () => {
    if (!user) return;
    
    setSaving(true);
    try {
      const { error } = await supabase
        .from('profiles')
        .update({
          first_name: profile.first_name,
          last_name: profile.last_name,
          department: profile.department,
          job_title: profile.job_title,
          email_training_reminders: profile.email_training_reminders,
          email_deadline_alerts: profile.email_deadline_alerts,
          email_completion_summary: profile.email_completion_summary,
          reminder_days_before: profile.reminder_days_before,
        })
        .eq('user_id', user.id);

      if (error) throw error;

      // Also save weekly goals
      await saveWeeklyGoals();

      toast({
        title: 'Profile updated',
        description: 'Your changes have been saved successfully.',
      });
    } catch (error) {
      console.error('Error updating profile:', error);
      toast({
        title: 'Error',
        description: 'Failed to update profile. Please try again.',
        variant: 'destructive',
      });
    } finally {
      setSaving(false);
    }
  };

  const initials = `${profile.first_name?.[0] || 'U'}${profile.last_name?.[0] || ''}`.toUpperCase();

  if (loading) {
    return (
      <div className="min-h-screen bg-background flex items-center justify-center">
        <Loader2 className="h-8 w-8 animate-spin text-primary" />
      </div>
    );
  }

  return (
    <div className="min-h-screen bg-background pb-24">
      {/* Header */}
      <div className="gradient-hero px-5 pt-12 pb-20">
        <div className="flex items-center gap-4 mb-6">
          <motion.button
            onClick={() => navigate('/')}
            className="p-2 rounded-xl bg-white/20 backdrop-blur-sm"
            whileHover={{ scale: 1.05 }}
            whileTap={{ scale: 0.95 }}
          >
            <ArrowLeft className="w-5 h-5 text-white" />
          </motion.button>
          <div className="flex-1">
            <img src={logo} alt="Flexible Healthcare" className="h-8 w-auto bg-white rounded-lg px-2 py-1" />
          </div>
        </div>
        <h1 className="text-2xl font-bold text-white">My Profile</h1>
        <p className="text-white/80 text-sm">Manage your personal information</p>
      </div>

      {/* Profile Card */}
      <div className="px-4 -mt-12">
        <motion.div
          className="bg-card rounded-2xl shadow-lg p-6 max-w-md mx-auto"
          initial={{ opacity: 0, y: 20 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ duration: 0.4 }}
        >
          {/* Avatar */}
          <div className="flex justify-center mb-6">
            <div className="relative">
              <input
                type="file"
                ref={fileInputRef}
                onChange={handleAvatarUpload}
                accept="image/*"
                className="hidden"
              />
              {profile.avatar_url ? (
                <img
                  src={profile.avatar_url}
                  alt="Avatar"
                  className="w-24 h-24 rounded-full object-cover border-4 border-primary/20"
                />
              ) : (
                <div className="w-24 h-24 rounded-full bg-primary flex items-center justify-center">
                  <span className="text-3xl font-bold text-primary-foreground">{initials}</span>
                </div>
              )}
              <motion.button
                onClick={() => fileInputRef.current?.click()}
                disabled={uploading}
                className="absolute bottom-0 right-0 p-2 rounded-full bg-primary text-primary-foreground shadow-lg"
                whileHover={{ scale: 1.1 }}
                whileTap={{ scale: 0.9 }}
              >
                {uploading ? (
                  <Loader2 className="w-4 h-4 animate-spin" />
                ) : (
                  <Camera className="w-4 h-4" />
                )}
              </motion.button>
            </div>
          </div>

          {/* Profile Completion Indicator */}
          <ProfileCompletionIndicator
            firstName={profile.first_name}
            lastName={profile.last_name}
            department={profile.department}
            jobTitle={profile.job_title}
            avatarUrl={profile.avatar_url}
          />

          {/* Email (read-only) */}
          <div className="mb-6 text-center">
            <p className="text-sm text-muted-foreground">{user?.email}</p>
          </div>

          {/* Form */}
          <div className="space-y-4">
            <div className="grid grid-cols-2 gap-3">
              <div className="space-y-2">
                <Label htmlFor="firstName">First Name</Label>
                <Input
                  id="firstName"
                  value={profile.first_name || ''}
                  onChange={(e) => setProfile({ ...profile, first_name: e.target.value })}
                  placeholder="Jane"
                />
              </div>
              <div className="space-y-2">
                <Label htmlFor="lastName">Last Name</Label>
                <Input
                  id="lastName"
                  value={profile.last_name || ''}
                  onChange={(e) => setProfile({ ...profile, last_name: e.target.value })}
                  placeholder="Smith"
                />
              </div>
            </div>

            <div className="space-y-2">
              <Label htmlFor="jobTitle">Job Title</Label>
              <Input
                id="jobTitle"
                value={profile.job_title || ''}
                onChange={(e) => setProfile({ ...profile, job_title: e.target.value })}
                placeholder="Registered Nurse"
              />
            </div>

            <div className="space-y-2">
              <Label htmlFor="department">Department</Label>
              <Input
                id="department"
                value={profile.department || ''}
                onChange={(e) => setProfile({ ...profile, department: e.target.value })}
                placeholder="Emergency Care"
              />
            </div>

            <Separator className="my-6" />

            {/* Notification Settings */}
            <div className="space-y-4">
              <div className="flex items-center gap-2 mb-4">
                <Bell className="w-5 h-5 text-primary" />
                <h3 className="font-semibold text-foreground">Email Notifications</h3>
              </div>

              <div className="flex items-center justify-between">
                <div className="space-y-0.5">
                  <Label htmlFor="training-reminders" className="text-sm font-medium">Training Reminders</Label>
                  <p className="text-xs text-muted-foreground">Get reminded about upcoming training</p>
                </div>
                <Switch
                  id="training-reminders"
                  checked={profile.email_training_reminders}
                  onCheckedChange={(checked) => setProfile({ ...profile, email_training_reminders: checked })}
                />
              </div>

              <div className="flex items-center justify-between">
                <div className="space-y-0.5">
                  <Label htmlFor="deadline-alerts" className="text-sm font-medium">Deadline Alerts</Label>
                  <p className="text-xs text-muted-foreground">Get alerts when deadlines are approaching</p>
                </div>
                <Switch
                  id="deadline-alerts"
                  checked={profile.email_deadline_alerts}
                  onCheckedChange={(checked) => setProfile({ ...profile, email_deadline_alerts: checked })}
                />
              </div>

              <div className="flex items-center justify-between">
                <div className="space-y-0.5">
                  <Label htmlFor="completion-summary" className="text-sm font-medium">Weekly Summary</Label>
                  <p className="text-xs text-muted-foreground">Receive weekly training completion summary</p>
                </div>
                <Switch
                  id="completion-summary"
                  checked={profile.email_completion_summary}
                  onCheckedChange={(checked) => setProfile({ ...profile, email_completion_summary: checked })}
                />
              </div>

              {profile.email_deadline_alerts && (
                <div className="space-y-2 pt-2">
                  <Label htmlFor="reminder-days">Remind me before deadline</Label>
                  <Select
                    value={profile.reminder_days_before.toString()}
                    onValueChange={(value) => setProfile({ ...profile, reminder_days_before: parseInt(value) })}
                  >
                    <SelectTrigger id="reminder-days">
                      <SelectValue placeholder="Select days" />
                    </SelectTrigger>
                    <SelectContent>
                      <SelectItem value="1">1 day before</SelectItem>
                      <SelectItem value="3">3 days before</SelectItem>
                      <SelectItem value="5">5 days before</SelectItem>
                      <SelectItem value="7">1 week before</SelectItem>
                    </SelectContent>
                  </Select>
                </div>
              )}
            </div>

            <Separator className="my-6" />

            {/* Weekly Goals Settings */}
            <div className="space-y-4">
              <div className="flex items-center gap-2 mb-4">
                <Target className="w-5 h-5 text-primary" />
                <h3 className="font-semibold text-foreground">Weekly Training Goals</h3>
              </div>

              <div className="space-y-2">
                <Label htmlFor="target-modules">Modules per week</Label>
                <Select
                  value={weeklyGoals.target_modules.toString()}
                  onValueChange={(value) => setWeeklyGoals({ ...weeklyGoals, target_modules: parseInt(value) })}
                >
                  <SelectTrigger id="target-modules">
                    <SelectValue placeholder="Select target" />
                  </SelectTrigger>
                  <SelectContent>
                    <SelectItem value="1">1 module</SelectItem>
                    <SelectItem value="2">2 modules</SelectItem>
                    <SelectItem value="3">3 modules</SelectItem>
                    <SelectItem value="5">5 modules</SelectItem>
                    <SelectItem value="7">7 modules</SelectItem>
                    <SelectItem value="10">10 modules</SelectItem>
                  </SelectContent>
                </Select>
              </div>

              <div className="space-y-2">
                <Label htmlFor="target-minutes">Training time per week</Label>
                <Select
                  value={weeklyGoals.target_minutes.toString()}
                  onValueChange={(value) => setWeeklyGoals({ ...weeklyGoals, target_minutes: parseInt(value) })}
                >
                  <SelectTrigger id="target-minutes">
                    <SelectValue placeholder="Select target" />
                  </SelectTrigger>
                  <SelectContent>
                    <SelectItem value="30">30 minutes</SelectItem>
                    <SelectItem value="60">1 hour</SelectItem>
                    <SelectItem value="90">1.5 hours</SelectItem>
                    <SelectItem value="120">2 hours</SelectItem>
                    <SelectItem value="180">3 hours</SelectItem>
                    <SelectItem value="300">5 hours</SelectItem>
                  </SelectContent>
                </Select>
              </div>
            </div>

            <Button onClick={handleSave} className="w-full mt-6" disabled={saving}>
              {saving ? (
                <>
                  <Loader2 className="mr-2 h-4 w-4 animate-spin" />
                  Saving...
                </>
              ) : (
                <>
                  <Save className="mr-2 h-4 w-4" />
                  Save Changes
                </>
              )}
            </Button>
          </div>
        </motion.div>
      </div>
    </div>
  );
}
