import { useState, useEffect } from 'react';
import { useNavigate } from 'react-router-dom';
import { useAuth } from '@/contexts/AuthContext';
import { supabase } from '@/integrations/supabase/client';
import { ArrowLeft, Loader2, Download, Award, Calendar, CheckCircle, AlertCircle } from 'lucide-react';
import { motion } from 'framer-motion';
import { Button } from '@/components/ui/button';
import { Badge } from '@/components/ui/badge';
import logo from '@/assets/logo.webp';
import { format } from 'date-fns';

interface ComplianceRecord {
  id: string;
  module_id: string;
  expiry_date: string | null;
  is_valid: boolean;
  created_at: string;
  certificate_url: string | null;
  module: {
    title: string;
    category: string;
  } | null;
}

export default function Certificates() {
  const { user } = useAuth();
  const navigate = useNavigate();
  const [loading, setLoading] = useState(true);
  const [records, setRecords] = useState<ComplianceRecord[]>([]);

  useEffect(() => {
    if (user) {
      fetchComplianceRecords();
    }
  }, [user]);

  const fetchComplianceRecords = async () => {
    if (!user) return;

    try {
      const { data, error } = await supabase
        .from('compliance_records')
        .select(`
          id,
          module_id,
          expiry_date,
          is_valid,
          created_at,
          certificate_url,
          module:training_modules(title, category)
        `)
        .eq('user_id', user.id)
        .order('created_at', { ascending: false });

      if (error) throw error;

      // Transform data to handle the relationship structure
      const transformedData = (data || []).map(record => ({
        ...record,
        module: Array.isArray(record.module) ? record.module[0] : record.module
      }));

      setRecords(transformedData);
    } catch (error) {
      console.error('Error fetching compliance records:', error);
    } finally {
      setLoading(false);
    }
  };

  const handleDownload = (certificateUrl: string | null, moduleTitle: string) => {
    if (certificateUrl) {
      window.open(certificateUrl, '_blank');
    } else {
      // Generate a simple certificate for demo purposes
      const certificateContent = `
CERTIFICATE OF COMPLETION

This is to certify that

${user?.email}

has successfully completed the training module:

${moduleTitle}

Date: ${format(new Date(), 'MMMM d, yyyy')}

Flexible Healthcare Training Platform
      `;
      
      const blob = new Blob([certificateContent], { type: 'text/plain' });
      const url = URL.createObjectURL(blob);
      const a = document.createElement('a');
      a.href = url;
      a.download = `${moduleTitle.replace(/\s+/g, '_')}_Certificate.txt`;
      document.body.appendChild(a);
      a.click();
      document.body.removeChild(a);
      URL.revokeObjectURL(url);
    }
  };

  const isExpired = (expiryDate: string | null) => {
    if (!expiryDate) return false;
    return new Date(expiryDate) < new Date();
  };

  if (loading) {
    return (
      <div className="min-h-screen bg-background flex items-center justify-center">
        <Loader2 className="h-8 w-8 animate-spin text-primary" />
      </div>
    );
  }

  return (
    <div className="min-h-screen bg-background pb-24">
      {/* Header */}
      <div className="gradient-hero px-5 pt-12 pb-20">
        <div className="flex items-center gap-4 mb-6">
          <motion.button
            onClick={() => navigate('/')}
            className="p-2 rounded-xl bg-white/20 backdrop-blur-sm"
            whileHover={{ scale: 1.05 }}
            whileTap={{ scale: 0.95 }}
          >
            <ArrowLeft className="w-5 h-5 text-white" />
          </motion.button>
          <div className="flex-1">
            <img src={logo} alt="Flexible Healthcare" className="h-8 w-auto bg-white rounded-lg px-2 py-1" />
          </div>
        </div>
        <div className="flex items-center gap-3">
          <Award className="w-8 h-8 text-white" />
          <div>
            <h1 className="text-2xl font-bold text-white">My Certificates</h1>
            <p className="text-white/80 text-sm">View and download your compliance certificates</p>
          </div>
        </div>
      </div>

      {/* Certificates List */}
      <div className="px-4 -mt-12">
        <motion.div
          className="bg-card rounded-2xl shadow-lg p-4 max-w-md mx-auto"
          initial={{ opacity: 0, y: 20 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ duration: 0.4 }}
        >
          {records.length === 0 ? (
            <div className="text-center py-12">
              <Award className="w-16 h-16 text-muted-foreground mx-auto mb-4" />
              <h3 className="text-lg font-semibold text-foreground mb-2">No Certificates Yet</h3>
              <p className="text-sm text-muted-foreground mb-4">
                Complete training modules to earn compliance certificates
              </p>
              <Button onClick={() => navigate('/learn')} variant="outline">
                Browse Training
              </Button>
            </div>
          ) : (
            <div className="space-y-4">
              <div className="flex items-center justify-between mb-4">
                <h2 className="font-semibold text-foreground">
                  {records.length} Certificate{records.length !== 1 ? 's' : ''}
                </h2>
              </div>
              
              {records.map((record, index) => {
                const expired = isExpired(record.expiry_date);
                
                return (
                  <motion.div
                    key={record.id}
                    className="border border-border rounded-xl p-4 bg-background"
                    initial={{ opacity: 0, y: 10 }}
                    animate={{ opacity: 1, y: 0 }}
                    transition={{ delay: index * 0.1 }}
                  >
                    <div className="flex items-start justify-between gap-3">
                      <div className="flex-1 min-w-0">
                        <div className="flex items-center gap-2 mb-1">
                          {record.is_valid && !expired ? (
                            <CheckCircle className="w-4 h-4 text-green-500 flex-shrink-0" />
                          ) : (
                            <AlertCircle className="w-4 h-4 text-amber-500 flex-shrink-0" />
                          )}
                          <h3 className="font-medium text-foreground truncate">
                            {record.module?.title || 'Unknown Module'}
                          </h3>
                        </div>
                        
                        <div className="flex flex-wrap gap-2 mt-2">
                          <Badge variant="secondary" className="text-xs">
                            {record.module?.category || 'General'}
                          </Badge>
                          {expired ? (
                            <Badge variant="destructive" className="text-xs">
                              Expired
                            </Badge>
                          ) : record.is_valid ? (
                            <Badge className="text-xs bg-green-500/10 text-green-600 border-green-500/20">
                              Valid
                            </Badge>
                          ) : (
                            <Badge variant="outline" className="text-xs">
                              Invalid
                            </Badge>
                          )}
                        </div>
                        
                        <div className="flex items-center gap-4 mt-3 text-xs text-muted-foreground">
                          <div className="flex items-center gap-1">
                            <Calendar className="w-3 h-3" />
                            <span>Issued: {format(new Date(record.created_at), 'MMM d, yyyy')}</span>
                          </div>
                          {record.expiry_date && (
                            <div className="flex items-center gap-1">
                              <span>Expires: {format(new Date(record.expiry_date), 'MMM d, yyyy')}</span>
                            </div>
                          )}
                        </div>
                      </div>
                      
                      <Button
                        size="sm"
                        variant="outline"
                        onClick={() => handleDownload(record.certificate_url, record.module?.title || 'Certificate')}
                        className="flex-shrink-0"
                      >
                        <Download className="w-4 h-4" />
                      </Button>
                    </div>
                  </motion.div>
                );
              })}
            </div>
          )}
        </motion.div>
      </div>
    </div>
  );
}
